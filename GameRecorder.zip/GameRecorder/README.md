# Game Recorder

Gravador de gameplay para Android. App próprio — não interage com outros jogos nem injeta nada em outros apps.

## Funções

- **Captura de tela** em MP4 (H.264, 30 fps, 8 Mbps) via MediaProjection
- **Áudio do microfone** (opcional) para comentário
- **Facecam flutuante** — câmera frontal em janela arrastável (CameraX)
- **Botão flutuante de parar** — arrastável, fica por cima do jogo
- **Modo stream** — silencia suas notificações pessoais durante a gravação
  (Não Perturbe / INTERRUPTION_FILTER_NONE) e restaura o estado ao parar
- Vídeo salvo em **Movies/GameRecorder** (aparece na galeria)

## Permissões pedidas

- Captura de tela (diálogo do sistema a cada início)
- Sobreposição (SYSTEM_ALERT_WINDOW) — para botão flutuante e facecam
- Câmera e microfone (em tempo de execução)
- Notificações (Android 13+)
- Acesso a Não Perturbe — só se usar o modo stream

## Como compilar o APK

Como aqui não há Android SDK, o APK é gerado por você:

1. Abra a pasta `GameRecorder` no **Android Studio** (Hedgehog ou mais novo).
2. Deixe o Gradle sincronizar (ele baixa o wrapper e as dependências).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - ou no terminal: `./gradlew assembleDebug`
4. O APK sai em `app/build/outputs/apk/debug/app-debug.apk`.

Para um APK de release assinado: **Build → Generate Signed Bundle / APK → APK**,
crie/escolha uma keystore e use a variante `release`.

## Config

- `minSdk 29` (Android 10) · `targetSdk 34` (Android 14)
- Internamente: `ScreenRecordService` é um `LifecycleService` que roda como
  foreground service com tipos `mediaProjection|camera`. A projeção só é obtida
  depois do `startForeground` (exigência do Android 14).
