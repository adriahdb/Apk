package com.djrec.gamerecorder

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageButton
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecordService : LifecycleService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_MIC = "mic"
        const val EXTRA_CAM = "cam"
        const val EXTRA_STREAM = "stream"
        private const val CHANNEL = "rec_channel"
        private const val NOTIF_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var outputUri: Uri? = null

    private lateinit var windowManager: WindowManager
    private var controlsView: View? = null
    private var camView: PreviewView? = null
    private var cameraProvider: ProcessCameraProvider? = null

    private var previousDndFilter: Int = -1
    private var streamMode = false

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> stopEverything()
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // Must be foreground (with the mediaProjection type) BEFORE obtaining the projection.
        startForegroundNotification()

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: run { stopSelf(); return }
        val mic = intent.getBooleanExtra(EXTRA_MIC, false)
        val cam = intent.getBooleanExtra(EXTRA_CAM, false)
        streamMode = intent.getBooleanExtra(EXTRA_STREAM, false)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopEverything() }
        }, null)

        if (streamMode) enableStreamMode()
        startRecording(mic)
        addFloatingControls()
        if (cam) addFacecam()
    }

    private fun startForegroundNotification() {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Gravacao", NotificationManager.IMPORTANCE_LOW)
            mgr.createNotificationChannel(ch)
        }
        val stopIntent = Intent(this, ScreenRecordService::class.java).apply { action = ACTION_STOP }
        val stopPi = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_recording))
            .setSmallIcon(R.drawable.ic_rec)
            .addAction(0, getString(R.string.stop), stopPi)
            .setOngoing(true)
            .build()

        startForeground(
            NOTIF_ID, notif,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )
    }

    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            dm.widthPixels = bounds.width()
            dm.heightPixels = bounds.height()
            dm.densityDpi = resources.configuration.densityDpi
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
        }
        return dm
    }

    private fun startRecording(mic: Boolean) {
        val dm = metrics()
        val width = dm.widthPixels / 2 * 2
        val height = dm.heightPixels / 2 * 2

        val name = "GR_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GameRecorder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        outputUri = contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
        ) ?: run { stopSelf(); return }

        val pfd = contentResolver.openFileDescriptor(outputUri!!, "w")
            ?: run { stopSelf(); return }

        recorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()).apply {
            if (mic) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(pfd.fileDescriptor)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (mic) setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setVideoSize(width, height)
            setVideoEncodingBitRate(8_000_000)
            setVideoFrameRate(30)
            prepare()
        }

        virtualDisplay = projection!!.createVirtualDisplay(
            "GameRecorder",
            width, height, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            recorder!!.surface, null, null
        )
        recorder!!.start()
    }

    private fun addFloatingControls() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 200
        }
        val v = LayoutInflater.from(this).inflate(R.layout.overlay_controls, null)
        v.findViewById<ImageButton>(R.id.btn_overlay_stop).setOnClickListener { stopEverything() }

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ix + (e.rawX - tx).toInt()
                    lp.y = iy + (e.rawY - ty).toInt()
                    windowManager.updateViewLayout(v, lp); true
                }
                else -> false
            }
        }
        controlsView = v
        windowManager.addView(v, lp)
    }

    private fun addFacecam() {
        val pv = PreviewView(this)
        val size = (resources.displayMetrics.density * 120).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24; y = 120
        }
        camView = pv
        windowManager.addView(pv, lp)

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                cameraProvider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(pv.surfaceProvider)
                }
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, preview
                )
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))

        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        pv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    // END gravity: moving right lowers x
                    lp.x = ix - (e.rawX - tx).toInt()
                    lp.y = iy + (e.rawY - ty).toInt()
                    windowManager.updateViewLayout(pv, lp); true
                }
                else -> false
            }
        }
    }

    private fun enableStreamMode() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            previousDndFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        }
    }

    private fun disableStreamMode() {
        if (previousDndFilter != -1) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(previousDndFilter)
            }
            previousDndFilter = -1
        }
    }

    private fun stopEverything() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null

        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null

        try { projection?.stop() } catch (_: Exception) {}
        projection = null

        outputUri?.let {
            val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            try { contentResolver.update(it, values, null, null) } catch (_: Exception) {}
        }
        outputUri = null

        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraProvider = null

        camView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        controlsView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        camView = null
        controlsView = null

        if (streamMode) disableStreamMode()

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
